class App{
    static instance = new App();
    installationWizards = [];

    generateUUID(){
        return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, c =>
            (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    }

    checkPermissions(){
        return {
            "outcome" : true,
            "message" : "User permissions validated",
            "permissions" : [
                {"value":true,"required":"ComputeAgentConnection"},
                {"value":true,"required":"ComputeAgentDeviceSetup"},
                {"value":true,"required":"ComputeAgentRoleForSetupWizard"},
                {"value":true,"required":"ComputeAgentSignin"},

            ]

        };
    }
}