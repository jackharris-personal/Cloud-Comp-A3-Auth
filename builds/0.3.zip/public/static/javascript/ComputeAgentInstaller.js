computeAgentInstaller = new Installer("Compute Agent",1.0);

computeAgentInstaller.bindToggleButton("SetupAgentButton","Compute Agent");

let prerequisites = new Page("Check of pre-requisites");

prerequisites.render = async function () {

    //Set the button text labels
    this.installerInstance.backButton.innerText = "Back";
    this.installerInstance.nextButton.innerText = "Next step";

    //Check the user permissions with the API
    let content = document.getElementById(this.installerInstance.contentDivPtr);

    let pageTitle = "<h2>"+this.title+"</h2><br>";

    let tableStart = "<table class='table table-striped'><thead> <tr> <th scope='col'>Required</th> <th scope='col'>Value</th><th scope='col'>Status</th> </tr></thead><tbody>";

    let tableContent = "";

    let tableEnd = "</tbody></table>";

    App.instance.checkPermissions().permissions.forEach((value) => {
        tableContent += "<tr><th scope='row'>"+value.required+"</th><td>"+value.value+"</td><td>OK</td></tr>"
    });

    content.innerHTML = pageTitle+tableStart+tableContent+tableEnd;

    if(!App.instance.checkPermissions().outcome){
        this.installerInstance.nextButton.href="#";
    }

}

computeAgentInstaller.addPage(prerequisites);

let settings = new Page("Configuration");

settings.render = function (){
    let content = document.getElementById(this.installerInstance.contentDivPtr);

    let pageTitle = "<h2>"+this.title+"</h2><br>";


    let contentBody = `<div class='overflow-scroll' style="padding: 8px">

        <div class="mb-3">
          <label for="name" class="form-label">Name</label>
          <input type="text" class="form-control" id="name" name="name" placeholder="Ubuntu Web Server" required min="5">
        </div>


        <div class="mb-3">
          <label for="rate" class="form-label">Polling rate</label>
         <select class="form-select" aria-label="Default select example" name="rate" id="rate">
          <option selected value="60">1 Minute</option>
          <option value="300">5 Minutes</option>
          <option value="600">10 Minutes</option>
          <option value="1800">30 Minutes</option>
          <option value="3600">60 Minutes</option>
        </select>
        </div>


        </div>`

    content.innerHTML = pageTitle+contentBody;

    if(this.installerInstance.variables.name !== undefined){
        document.getElementById("name").value = this.installerInstance.variables.name;
    }
}

settings.onNextButtonPress = function (){
    let name = document.getElementById("name");


    if(name.value.length >= 5){

        this.installerInstance.variables.name = name.value;
        this.installerInstance.variables.rate = 60;

        this.installerInstance.activePage++;
        this.installerInstance.render();
    }

}

computeAgentInstaller.addPage(settings);

let preInstallationSummery = new Page("Pre-connection summary");

preInstallationSummery.render = function () {
    let content = document.getElementById(this.installerInstance.contentDivPtr);

    let pageTitle = "<h2>"+this.title+"</h2><br><p>Please check configuration parameters. if all is correct, press the 'Next Step', or 'Back' to change the configuration parameters</p>";

    let contentBody = "";

    Object.keys(this.installerInstance.variables).forEach(key => {
        let value = this.installerInstance.variables[key];

        contentBody += "<p><strong>"+key+":</strong> "+value+"</p>";
    });

    content.innerHTML = pageTitle+contentBody;

}

computeAgentInstaller.addPage(preInstallationSummery);

let connection = new Page("Connection");

connection.render = async function () {

    this.installerInstance.nextButton.innerText = "Exit";

    let content = document.getElementById(this.installerInstance.contentDivPtr);

    let bodyContent = `
 
    <h2>` + this.title + `</h2><br><p>Waiting for agent to make a connection.....</p>

    <div style='text-align: center'>
        <img src="/static/images/loading.gif" alt="Loading..." style="width: 256px"> 
    </div>
    
    <p>Please login to the agent and enter the linking code</p>
    <div style="display: flex; flex-direction: row"><input type="text" readonly id="connectionCode"></div>
    `;

    content.innerHTML = bodyContent;

    HttpClient.post("/api/compute-agent-generate-key","").then((data)=>{
        console.log(data);
    })

}


computeAgentInstaller.addPage(connection);

computeAgentInstaller.initialize();
