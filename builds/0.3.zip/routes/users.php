<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - nextstats-auth
 * Last Updated - 5/11/2023
 */

use app\controllers\HomeController;
use App\Framework\Facades\Route;

//User endpoints
Route::get("/user/{user_id}","getUserDetails",HomeController::class);
Route::get("/user/{user_id}/photo","getUserPhoto",HomeController::class);

//Me endpoints
Route::get("/me","getMyDetails",HomeController::class);