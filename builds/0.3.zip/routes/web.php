<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - forum
 * Last Updated - 9/09/2023
 */

use app\controllers\HomeController;
use App\Framework\Facades\Route;

Route::get("/me/drive/items/{item_id}/workbook/worksheets","getWorkSheets",HomeController::class);