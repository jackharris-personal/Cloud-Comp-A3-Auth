<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - nextstats-web
 * Last Updated - 30/10/2023
 */

namespace App\Framework;

use mysqli;
use mysqli_result;

class Database
{

    public static function query(string $query): mysqli_result|bool
    {
        return Database::getConnection()->query($query);
    }

    public static function fetch(string $query): array
    {
        return Database::getConnection()->query($query)->fetch_assoc();
    }

    private static function getConnection(): mysqli
    {
        $username = "admin";
        $password = "w_9q&&CkCrs2Y;";
        $host = "policymanager-rds.cf9mfscrskio.ap-southeast-2.rds.amazonaws.com";
        $database = "policymanager";
        $port = 3306;

        //$username = App::Env("DB_USERNAME");
        //$password = App::Env("DB_PASSWORD");
        //$host = App::Env("DB_HOST");

        return new mysqli($host,$username,$password,$database,$port);
    }

}