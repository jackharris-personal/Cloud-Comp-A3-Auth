<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - policyManager-AuthApi
 * Last Updated - 8/11/2023
 */

namespace App\Framework\Facades;

class CommandLine
{

    public static function call(string $command){

    }

    public static function register(string $command, string $method, $class){

    }

}