class HttpClient {


    static async post(uri, data) {

        return (await fetch(uri, {
            method: "POST",
            mode: "no-cors",
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: data
        })).json();

    }





}