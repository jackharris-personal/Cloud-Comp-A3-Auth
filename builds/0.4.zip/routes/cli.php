<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - policyManager-AuthApi
 * Last Updated - 8/11/2023
 */

use App\Controllers\CommandTesting;
use App\Framework\Facades\CommandLine;

CommandLine::register("Model:migrate {class}","test", CommandTesting::class);

CommandLine::register("Model:update {class}","test", CommandTesting::class);