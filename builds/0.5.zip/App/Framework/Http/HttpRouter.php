<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - forum
 * Last Updated - 9/09/2023
 */

namespace App\Framework\Http;


use App\Framework\Router;

class HttpRouter extends Router
{

    public function GetUriAsArray(string $url = null): array
    {
        if($url === null){
            $url = $_SERVER["REQUEST_URI"];
        }

        if(strpos($url,"?")){
            $url = substr($url, 0, strrpos($url,"?"));
        }

        return array_filter(explode("/", $url));
    }


    public function registerRoute(string $uri, string $type, string $method, $controller): void
    {

        $this->routes[$type][$this->prefix.$uri] = ["controller"=>$controller,"method"=>$method];
    }

    public function analyseRouteAndLookup(array $route): array
    {

        $uri = $route;
        $routes = $this->routes[$_SERVER["REQUEST_METHOD"]];

        $response = [
            "route"=>null,
            "outcome"=>false
        ];

        foreach ($routes as $key => $route){

            $routeKey = $this->GetUriAsArray($key);
            $variables = [];
            $checks = [1=>false];

            if(count($routeKey) === count($uri)){

                $count  = 1;
                foreach ($routeKey as $section){

                    if(!$this->CheckForVariable($section)){
                        if($uri[$count] === $section){
                            $checks[$count] = true;
                        }else{
                            $checks[$count] = false;
                        }
                    }else{
                        $variables[ltrim(rtrim($section,'}'),'{')] = $uri[$count];
                    }
                    $count++;
                }
            }

            if(!in_array(false,$checks,true)){

                $response["route"] = $key;
                $response["outcome"] = true;
                $response["controller"] = $route["controller"];
                $response["method"] =  $route["method"];
                $response["variables"] = $variables;
                break;
            }
        }

        return $response;
    }

    function loadRoutes(string $file, string|null $prefix = null): void
    {
        if($prefix !== null){
            $this->prefix = $prefix;
        }
        require_once ROUTES.$file;
    }
}