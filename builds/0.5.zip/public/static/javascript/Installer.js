
class Installer {

    isShown = false;
    pages = [];
    app_name;
    app_version;
    activePage;
    overlay;
    element;
    nextButton;
    backButton;
    id;

    pageListPtr;
    contentDivPtr;

    variables = {};


    constructor(app_name, app_version) {

        this.app_name = app_name;
        this.app_version = app_version;
        this.activePage = 0;
        this.overlay = document.createElement("div");
        this.overlay.classList.add("overlay");
        this.overlay.style.display = "none";
        this.id = App.instance.generateUUID();

        document.getElementById("page-wrapper").appendChild(this.overlay);


        this.element = this.generateInstaller();


        let welcome = new Page("Welcome");
        welcome.setInstallerInstance(this);

        welcome.render = function () {

            this.installerInstance.backButton.innerText = "Cancel";
            this.installerInstance.nextButton.innerText = "Start setup";

            let content = document.getElementById(this.installerInstance.contentDivPtr);

            content.innerHTML = "<div style='position: relative' class='center'><h2>Setup Wizard</h2><h1>"+this.installerInstance.app_name+" v"+app_version+"</h1></div>";

        }

        welcome.onBackButtonPress= function () {
            this.installerInstance.toggleWindow();
        }

        this.pages.push(welcome);

        this.element.style.display = "none";
        document.getElementById("page-wrapper").appendChild(this.element);

        App.instance.installationWizards[app_name] = this;
    }

    initialize(){
        this.render();
    }

    addPage(page){
        this.pages.push(page);
        page.setInstallerInstance(this);
    }

    bindToggleButton(button,instance){
        document.getElementById(button).href = "javascript: App.instance.installationWizards['"+instance+"'].toggleWindow()";
    }

    render(){

        let list = document.getElementById(this.pageListPtr);
        list.innerHTML = "";

        let count = 0;

        this.pages.forEach(page =>{
            let item = document.createElement("li");

            if(count === this.activePage){
                item.classList.add("active");
            }

            if(count !== 0){
                item.innerText=  count+") "+page.title;
            }else{
                item.innerText=  page.title;

            }

            list.appendChild(item);
            count++;
        });

        this.pages[this.activePage].render();
    }


    toggleWindow(){

        if(!this.isShown){
            this.isShown = true;
            this.overlay.style.display = "block";
            this.element.style.display = "block";
        }else{
            this.isShown = false;
            this.overlay.style.display = "none";
            this.element.style.display = "none";

        }
    }

    onNextButtonPress(){

        if(this.pages[this.activePage].onNextButtonPress !== undefined){
            this.pages[this.activePage].onNextButtonPress();
        }else{

            if(this.activePage < this.pages.length){
                this.activePage++;
                this.render();
            }

        }

    }

    onBackButtonPress(){

        if(this.pages[this.activePage].onBackButtonPress !== undefined){
            this.pages[this.activePage].onBackButtonPress();
        }else{

            if(this.activePage > 0){
                this.activePage--;
                this.render();
            }

        }
    }

    generateInstaller(){
        let outerDiv = document.createElement("div");
        outerDiv.classList.add("setup-window");

        let columnContainer = document.createElement("div");
        columnContainer.classList.add("column-container");

        let left = document.createElement("div");
        left.classList.add("left");
        columnContainer.appendChild(left);

        let leftHeader =  document.createElement("div");
        leftHeader.classList.add("header");

        let logo = document.createElement("img");
        logo.src = "https://resources.nextstats.net/images/NextStatsLogo.png";
        logo.alt = "Next Stats";

        leftHeader.appendChild(logo);

        left.appendChild(leftHeader);

        let list = document.createElement("ol");
        list.id = App.instance.generateUUID();
        this.pageListPtr = list.id;
        left.appendChild(list);

        let right = document.createElement("div");
        right.classList.add("right");

        let rightContainer = document.createElement("div");

        rightContainer.id =  App.instance.generateUUID();
        this.contentDivPtr = rightContainer.id;

        right.appendChild(rightContainer);

        columnContainer.appendChild(right);

        outerDiv.appendChild(columnContainer);

        let footer = document.createElement("div");

        let nextButton = document.createElement("a");
        nextButton.innerText = "Next step";
        nextButton.className = "button button-primary";
        nextButton.href = "javascript:App.instance.installationWizards['"+this.app_name+"'].onNextButtonPress()";
        this.nextButton = nextButton;

        let backButton = document.createElement("a");
        backButton.innerText = "Back";
        backButton.id = "TEST";
        backButton.href  = "javascript:App.instance.installationWizards['"+this.app_name+"'].onBackButtonPress()";
        backButton.className = "button button-secondary";
        this.backButton = backButton;

        footer.appendChild(nextButton);
        footer.appendChild(backButton);

        footer.classList.add("footer");

        outerDiv.appendChild(footer);

        return outerDiv;
    }
}

class Page {

    title;
    installerInstance;
    render;
    onBackButtonPress;
    onNextButtonPress;

    constructor(title) {
        this.title = title;
    }

    setInstallerInstance(instance){
        this.installerInstance = instance;
    }

}