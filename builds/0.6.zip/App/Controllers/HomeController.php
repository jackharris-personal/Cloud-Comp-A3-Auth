<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - forum
 * Last Updated - 9/09/2023
 */

namespace App\Controllers;

class HomeController
{

    public function getUserDetails(string $user_id){

        return "What user?";
    }

    public function getMyDetails(){

        return "Here are your details!";
    }

    public function getUserPhoto(string $user_id){
        return "This is a image!";
    }

}