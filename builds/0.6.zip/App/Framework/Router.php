<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - policyManager-AuthApi
 * Last Updated - 8/11/2023
 */

namespace App\Framework;

abstract class Router
{


    public static string $ROUTE_POST = "POST";
    public static string $ROUTE_GET = "GET";
    public static string $ROUTE_PATCH = "PATCH";
    public static string $ROUTE_DELETE = "DELETE";
    public static string $ROUTE_CLI = "CLI";

    protected array $routes;

    protected $prefix;


    abstract function registerRoute(string $uri, string $type, string $method, $controller);

    abstract function loadRoutes(string $file,string $prefix = null);

    protected function CheckForVariable(string $section): bool
    {
        $outcome = false;

        if(str_starts_with($section, '{') && str_ends_with($section, '}')){

            $outcome = true;

        }

        return $outcome;
    }

}