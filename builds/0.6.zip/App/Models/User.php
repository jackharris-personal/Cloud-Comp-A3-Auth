<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - forum
 * Last Updated - 29/09/2023
 */

namespace app\models;

use App\Framework\Database;
use app\Framework\Database\Attributes\DatabaseColumn;


class User
{

    #[DatabaseColumn([
        "PRIMARY_KEY"=>true,
        "TYPE"=>SQL_TYPE_INT,
        "ALLOW_NULL"=>false,
        "AUTO_INCREMENT"=>true
    ])]
    private int $id;

    #[DatabaseColumn(["TYPE"=>SQL_TYPE_VARCHAR])]
    private string $mail;

    #[DatabaseColumn(["TYPE"=>SQL_TYPE_VARCHAR])]
    private string $givenName;

    #[DatabaseColumn(["TYPE"=>SQL_TYPE_VARCHAR])]
    private string $surname;

    #[DatabaseColumn(["TYPE"=>SQL_TYPE_VARCHAR])]
    private string $displayName;

    #[DatabaseColumn(["TYPE"=>SQL_TYPE_VARCHAR])]
    private string $jobTitle;

    #[DatabaseColumn(["TYPE"=>SQL_TYPE_VARCHAR])]
    private string $company;

    #[DatabaseColumn(["TYPE"=>SQL_TYPE_VARCHAR])]
    private string $password;

    private array $entity;

    public function __construct(Array $entity){

        $this->id = $entity["id"];
        $this->mail = $entity["email"];
        $this->givenName = $entity["givenName"];
        $this->surname = $entity["surname"];
        $this->displayName = $entity["displayName"];
        $this->password = $entity["password"];
        $this->entity = $entity;

        unset($this->entity["password"]);
    }

    public function GetId(): int
    {
        return $this->id;
    }

    public function GetFirstname(): string
    {
        return $this->firstname;
    }

    public function GetLastname(): string{
        return $this->lastname;
    }

    public function GetEmail(): string
    {
        return $this->email;
    }


    public function GetPassword(): string
    {
        return $this->password;
    }

    public function getEntity(): array
    {
        return $this->entity;
    }


    public static function LookUpByEmail(string $email): ?User
    {

        $query = "SELECT * FROM accounts WHERE email='$email'";

        $result = Database::query($query);

        if($result->num_rows > 0){
            return new User($result->fetch_assoc());
        }else{
            return null;
        }

    }

    public static function LookUpByUsername(string $username): ?User
    {
        return User::$users[0];
    }

    public static function register(string $email, string $firstname, string $lastname, string $password): bool
    {

        $query = "INSERT INTO accounts (email, firstname, lastname, password) VALUES ('$email','$firstname','$lastname','$password')";

        if(Database::query($query)){
            return true;
        }else{
            return false;
        }

    }



}