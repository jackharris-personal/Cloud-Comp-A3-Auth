<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - policyManager-AuthApi
 * Last Updated - 8/11/2023
 */

const SQL_TYPE_INT = 4;
const SQL_TYPE_VARCHAR = 12;
const SQL_TYPE_TEXT = 10;

